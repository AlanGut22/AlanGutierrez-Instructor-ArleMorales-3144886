import pandas as pd
import plotly.express as px

# Nombre del archivo y hoja
archivo_excel = 'presupuesto_proyecto_v1.xlsx'
nombre_hoja = 'CostosDirectos'

print(f"--- Leyendo el archivo: {archivo_excel} ---")

try:
    df_costos = pd.read_excel(archivo_excel, sheet_name=nombre_hoja)

    # Mostrar los datos leídos
    print("\nDatos leídos desde Excel:")
    print(df_costos)

    # Calcular la columna 'Costo Total (COP)'
    df_costos['Costo Total (COP)'] = df_costos['Horas Estimadas'] * df_costos['Tarifa por Hora (COP)']

    # Calcular el costo total del proyecto
    costo_total_proyecto = df_costos['Costo Total (COP)'].sum()

    # Mostrar los resultados
    print("\n--- Presupuesto Calculado ---")
    print("\nDetalle de costos por tarea:")
    print(df_costos)

    print("\n-----------------------------------------------------")
    print(f"Costo Total Directo del Proyecto: ${costo_total_proyecto:,.2f} COP")
    print("-----------------------------------------------------")
    
    # Crear gráfica
    fig = px.bar(
        df_costos,
        x='Tarea / Actividad',
        y='Costo Total (COP)',
        title='Costo Total por Tarea',
        labels={'Costo Total (COP)': 'Costo (COP)', 'Tarea / Actividad': 'Tarea'},
        text='Costo Total (COP)'
        )

    fig.update_traces(texttemplate='%{text:,.0f}', textposition='outside')
    fig.update_layout(uniformtext_minsize=8, uniformtext_mode='hide')

    # Exportar como HTML
    fig.write_html("grafico_presupuesto.html")
    print("\n✅ Gráfico guardado como 'grafico_presupuesto.html'. Puedes abrirlo en tu navegador.")

except FileNotFoundError:
    print(f"\n❌ ¡ERROR! No se encontró el archivo '{archivo_excel}'.")
    print("Asegúrate de que esté en la misma carpeta que el script.")
except Exception as e:
    print(f"\n❌ Error inesperado: {e}")