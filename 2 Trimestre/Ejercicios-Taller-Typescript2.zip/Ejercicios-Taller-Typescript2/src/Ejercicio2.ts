import readline from 'readline';

interface Evento {
	id: string;
	nombre: string;
	categoria: string;
	fecha: string; // formato: YYYY-MM-DD
	cupoMaximo: number;
	participantes: string[];
}

const eventos: Evento[] = [
	{
		id: 'e1',
		nombre: 'Taller de JavaScript',
		categoria: 'Taller',
		fecha: '2025-05-20',
		cupoMaximo: 30,
		participantes: ['Ana', 'Luis', 'Carlos'],
	},
	{
		id: 'e2',
		nombre: 'Seminario de IA',
		categoria: 'Seminario',
		fecha: '2025-05-22',
		cupoMaximo: 50,
		participantes: ['Marta', 'Pedro'],
	},
	{
		id: 'e3',
		nombre: 'Conferencia UX',
		categoria: 'Conferencia',
		fecha: '2025-06-01',
		cupoMaximo: 100,
		participantes: [],
	},
];

// Funciones del sistema

function filtrarEventos(opcion: 'fecha' | 'categoria', valor: string) {
	if (opcion === 'fecha') {
		return eventos.filter((e) => e.fecha === valor);
	} else {
		return eventos.filter((e) => e.categoria.toLowerCase() === valor.toLowerCase());
	}
}

function obtenerParticipantes(idEvento: string): string[] {
	const evento = eventos.find((e) => e.id === idEvento);
	return evento ? evento.participantes : [];
}

function verificarDisponibilidad(idEvento: string): boolean {
	const evento = eventos.find((e) => e.id === idEvento);
	return evento ? evento.participantes.length < evento.cupoMaximo : false;
}

function generarCertificados(idEvento: string): string[] {
	const evento = eventos.find((e) => e.id === idEvento);
	if (!evento) return [];
	return evento.participantes.map((nombre) =>
		`Certificado: ${nombre} participó en el evento "${evento.nombre}" (${evento.categoria}) el ${evento.fecha}`
	);
}

function calcularEstadisticasAsistencia(): Record<string, number> {
	const stats: Record<string, number> = {};
	for (const evento of eventos) {
		const tipo = evento.categoria;
		if (!stats[tipo]) stats[tipo] = 0;
		stats[tipo] += evento.participantes.length;
	}
	return stats;
}

// Interfaz básica por consola

const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout,
});

function mostrarMenu() {
	console.log('\n--- MENÚ DE GESTIÓN DE EVENTOS ---');
	console.log('1. Filtrar eventos por fecha o categoría');
	console.log('2. Ver lista de participantes en un evento');
	console.log('3. Verificar disponibilidad de cupo en un evento');
	console.log('4. Generar certificados de un evento');
	console.log('5. Calcular estadísticas de asistencia por tipo de evento');
	console.log('0. Salir');
}

function iniciarMenu() {
	mostrarMenu();
	rl.question('\nSeleccione una opción: ', (opcion) => {
		switch (opcion) {
			case '1':
				rl.question('¿Filtrar por fecha o categoría? (fecha/categoria): ', (tipo) => {
					rl.question(`Ingrese el valor (${tipo}): `, (valor) => {
						const resultados = filtrarEventos(tipo as any, valor);
						console.log('\nEventos encontrados:');
						resultados.forEach((e) => console.log(`${e.nombre} - ${e.fecha} - ${e.categoria}`));
						iniciarMenu();
					});
				});
				break;
			case '2':
				rl.question('Ingrese el ID del evento: ', (id) => {
					const participantes = obtenerParticipantes(id);
					console.log('\nParticipantes inscritos:');
					participantes.forEach((p) => console.log(p));
					iniciarMenu();
				});
				break;
			case '3':
				rl.question('Ingrese el ID del evento: ', (id) => {
					const disponible = verificarDisponibilidad(id);
					console.log(disponible ? 'Cupos disponibles ✅' : 'No hay cupos disponibles ❌');
					iniciarMenu();
				});
				break;
			case '4':
				rl.question('Ingrese el ID del evento: ', (id) => {
					const certificados = generarCertificados(id);
					console.log('\nCertificados generados:');
					certificados.forEach((c) => console.log(c));
					iniciarMenu();
				});
				break;
			case '5':
				const stats = calcularEstadisticasAsistencia();
				console.log('\nEstadísticas de asistencia:');
				Object.entries(stats).forEach(([tipo, cantidad]) =>
					console.log(`${tipo}: ${cantidad} asistentes`)
				);
				iniciarMenu();
				break;
			case '0':
				console.log('Saliendo...');
				rl.close();
				break;
			default:
				console.log('Opción no válida');
				iniciarMenu();
		}
	});
}

// Ejecutar el menú
iniciarMenu();