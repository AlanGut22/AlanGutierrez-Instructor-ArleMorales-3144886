import readline from 'readline';

const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout,
});

type Evento = {
	id: string;
	nombre: string;
	categoria: string;
	fecha: string;
	cupoMaximo: number;
	participantes: string[];
};

const eventos: Evento[] = [
	{
		id: '1',
		nombre: 'Conferencia UX',
		categoria: 'conferencia',
		fecha: '2025-06-01',
		cupoMaximo: 100,
		participantes: ['Ana', 'Luis'],
	},
	{
		id: '2',
		nombre: 'Seminario de IA',
		categoria: 'seminario',
		fecha: '2025-05-22',
		cupoMaximo: 50,
		participantes: ['Pedro'],
	},
	{
		id: '3',
		nombre: 'Taller de JavaScript',
		categoria: 'taller',
		fecha: '2025-05-20',
		cupoMaximo: 30,
		participantes: ['Carlos', 'Marta'],
	},
];

function filtrarEventos() {
	rl.question('¿Filtrar por "fecha" o "categoria"? ', (tipo) => {
		rl.question(`Ingrese el valor para ${tipo}: `, (valor) => {
			const filtrados = eventos.filter((e) =>
				tipo === 'fecha' ? e.fecha === valor : e.categoria.toLowerCase() === valor.toLowerCase()
			);
			console.log('\nEventos encontrados:');
			filtrados.forEach((e) => {
				console.log(`${e.nombre} - ${e.fecha} - ${e.categoria}`);
			});
			iniciar();
		});
	});
}

function verParticipantes() {
	rl.question('Ingrese el ID del evento: ', (id) => {
		const evento = eventos.find((e) => e.id === id);
		if (evento) {
			console.log('\nParticipantes:');
			evento.participantes.forEach((p) => console.log(p));
		} else {
			console.log('Evento no encontrado.');
		}
		iniciar();
	});
}

function verificarCupos() {
	rl.question('Ingrese el ID del evento: ', (id) => {
		const evento = eventos.find((e) => e.id === id);
		if (evento) {
			const disponibles = evento.cupoMaximo - evento.participantes.length;
			console.log(`Cupos disponibles: ${disponibles}`);
		} else {
			console.log('Evento no encontrado.');
		}
		iniciar();
	});
}

function generarCertificados() {
	rl.question('Ingrese el ID del evento: ', (id) => {
		const evento = eventos.find((e) => e.id === id);
		if (evento) {
			console.log('\nCertificados:');
			evento.participantes.forEach((p) => {
				console.log(`Certificado: ${p} participó en "${evento.nombre}" el ${evento.fecha}`);
			});
		} else {
			console.log('Evento no encontrado.');
		}
		iniciar();
	});
}

function verEstadisticas() {
	const conteo: Record<string, number> = {};
	eventos.forEach((e) => {
		if (!conteo[e.categoria]) conteo[e.categoria] = 0;
		conteo[e.categoria] += e.participantes.length;
	});
	console.log('\nAsistencias por categoría:');
	for (const categoria in conteo) {
		console.log(`${categoria}: ${conteo[categoria]} personas`);
	}
	iniciar();
}

function mostrarMenu() {
	console.log('\n--- MENÚ DE EVENTOS ---');
	console.log('1. Filtrar eventos');
	console.log('2. Ver participantes');
	console.log('3. Verificar cupos');
	console.log('4. Generar certificados');
	console.log('5. Ver estadísticas');
	console.log('0. Salir');
}

// Lógica principal
function iniciar() {
	mostrarMenu();
	rl.question('Seleccione una opción: ', (op) => {
		switch (op) {
			case '1':
				filtrarEventos();
				break;
			case '2':
				verParticipantes();
				break;
			case '3':
				verificarCupos();
				break;
			case '4':
				generarCertificados();
				break;
			case '5':
				verEstadisticas();
				break;
			case '0':
				console.log('¡Hasta luego!');
				rl.close();
				break;
			default:
				console.log('Opción no válida.');
				iniciar();
		}
	});
}

iniciar();