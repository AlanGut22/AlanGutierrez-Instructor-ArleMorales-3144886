import * as readline from 'readline';

// Interfaces para los modelos
interface Paciente {
	id: string;
	nombre: string;
	edad: number;
}

interface Medico {
	id: string;
	nombre: string;
	especialidad: string;
}

interface Cita {
	id: string;
	pacienteId: string;
	medicoId: string;
	fecha: string; // Formato 'YYYY-MM-DD'
	hora: string;  // Formato 'HH:MM'
}

// GestorCitas con las operaciones
class GestorCitas {
	pacientes: Paciente[] = [];
	medicos: Medico[] = [];
	citas: Cita[] = [];

	agregarPaciente(paciente: Paciente) {
		this.pacientes.push(paciente);
	}

	agregarMedico(medico: Medico) {
		this.medicos.push(medico);
	}

	agendarCita(cita: Cita) {
		this.citas.push(cita);
	}

	filtrarCitasPorEspecialidad(especialidad: string): Cita[] {
		const medicos = this.medicos.filter(m => m.especialidad === especialidad).map(m => m.id);
		return this.citas.filter(c => medicos.includes(c.medicoId));
	}

	obtenerCitasDePaciente(pacienteId: string): Cita[] {
		return this.citas.filter(c => c.pacienteId === pacienteId);
	}

	obtenerCitasPorFecha(fecha: string): Cita[] {
		return this.citas.filter(c => c.fecha === fecha);
	}

	generarReporteDiario(fecha: string): string {
		const citasDelDia = this.obtenerCitasPorFecha(fecha);
		return citasDelDia.map(c => {
			const paciente = this.pacientes.find(p => p.id === c.pacienteId);
			const medico = this.medicos.find(m => m.id === c.medicoId);
			return `Hora: ${c.hora}, Paciente: ${paciente?.nombre}, Doctor: ${medico?.nombre}, Especialidad: ${medico?.especialidad}`;
		}).join('\n');
	}

	estaDisponible(medicoId: string, fecha: string, hora: string): boolean {
		return !this.citas.some(c => c.medicoId === medicoId && c.fecha === fecha && c.hora === hora);
	}
}

// Configuración de readline para entrada del usuario
const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout
});

const gestor = new GestorCitas();

// Datos predeterminados (grupo de personas)
const pacientes: Paciente[] = [
	{ id: 'p1', nombre: 'Juan Pérez', edad: 30 },
	{ id: 'p2', nombre: 'Ana Gómez', edad: 25 },
	{ id: 'p3', nombre: 'Carlos López', edad: 40 }
];

const medicos: Medico[] = [
	{ id: 'm1', nombre: 'Dra. Gómez', especialidad: 'Cardiología' },
	{ id: 'm2', nombre: 'Dr. Ruiz', especialidad: 'Pediatría' },
	{ id: 'm3', nombre: 'Dr. Martínez', especialidad: 'Ginecología' }
];

// Agregar los pacientes y médicos predeterminados al gestor
pacientes.forEach(paciente => gestor.agregarPaciente(paciente));
medicos.forEach(medico => gestor.agregarMedico(medico));

// Función para manejar el menú
function mostrarMenu() {
	console.log('\n--- MENÚ DE GESTIÓN DE CITAS ---');
	console.log('1. Agregar paciente');
	console.log('2. Agregar médico');
	console.log('3. Agendar cita');
	console.log('4. Filtrar citas por especialidad');
	console.log('5. Obtener citas de un paciente');
	console.log('6. Obtener citas por fecha');
	console.log('7. Generar reporte diario');
	console.log('8. Verificar disponibilidad de doctor');
	console.log('9. Salir');

	rl.question('Seleccione una opción: ', (opcion) => {
		switch (opcion) {
			case '1':
				agregarPaciente();
				break;
			case '2':
				agregarMedico();
				break;
			case '3':
				agendarCita();
				break;
			case '4':
				filtrarCitasPorEspecialidad();
				break;
			case '5':
				obtenerCitasDePaciente();
				break;
			case '6':
				obtenerCitasPorFecha();
				break;
			case '7':
				generarReporteDiario();
				break;
			case '8':
				verificarDisponibilidad();
				break;
			case '9':
				rl.close();
				break;
			default:
				console.log('Opción no válida.');
				mostrarMenu();
		}
	});
}

// Funciones de cada opción
function agregarPaciente() {
	rl.question('Ingrese ID del paciente: ', (id) => {
		rl.question('Ingrese nombre del paciente: ', (nombre) => {
			rl.question('Ingrese edad del paciente: ', (edad) => {
				gestor.agregarPaciente({ id, nombre, edad: Number(edad) });
				console.log('Paciente agregado.');
				mostrarMenu();
			});
		});
	});
}

function agregarMedico() {
	rl.question('Ingrese ID del médico: ', (id) => {
		rl.question('Ingrese nombre del médico: ', (nombre) => {
			rl.question('Ingrese especialidad del médico: ', (especialidad) => {
				gestor.agregarMedico({ id, nombre, especialidad });
				console.log('Médico agregado.');
				mostrarMenu();
			});
		});
	});
}

function agendarCita() {
	rl.question('Ingrese ID del paciente: ', (pacienteId) => {
		rl.question('Ingrese ID del médico: ', (medicoId) => {
			rl.question('Ingrese fecha de la cita (YYYY-MM-DD): ', (fecha) => {
				rl.question('Ingrese hora de la cita (HH:MM): ', (hora) => {
					const id = `cita_${Date.now()}`;
					gestor.agendarCita({ id, pacienteId, medicoId, fecha, hora });
					console.log('Cita agendada.');
					mostrarMenu();
				});
			});
		});
	});
}

function filtrarCitasPorEspecialidad() {
	rl.question('Ingrese especialidad: ', (especialidad) => {
		const citas = gestor.filtrarCitasPorEspecialidad(especialidad);
		console.log('Citas filtradas:', citas);
		mostrarMenu();
	});
}

function obtenerCitasDePaciente() {
	rl.question('Ingrese ID del paciente: ', (pacienteId) => {
		const citas = gestor.obtenerCitasDePaciente(pacienteId);
		console.log('Citas del paciente:', citas);
		mostrarMenu();
	});
}

function obtenerCitasPorFecha() {
	rl.question('Ingrese fecha (YYYY-MM-DD): ', (fecha) => {
		const citas = gestor.obtenerCitasPorFecha(fecha);
		console.log('Citas de la fecha:', citas);
		mostrarMenu();
	});
}

function generarReporteDiario() {
	rl.question('Ingrese fecha (YYYY-MM-DD): ', (fecha) => {
		const reporte = gestor.generarReporteDiario(fecha);
		console.log('Reporte del día:', reporte);
		mostrarMenu();
	});
}

function verificarDisponibilidad() {
	rl.question('Ingrese ID del médico: ', (medicoId) => {
		rl.question('Ingrese fecha (YYYY-MM-DD): ', (fecha) => {
			rl.question('Ingrese hora (HH:MM): ', (hora) => {
				const disponible = gestor.estaDisponible(medicoId, fecha, hora);
				console.log(`¿Disponible?: ${disponible}`);
				mostrarMenu();
			});
		});
	});
}

// Iniciar el menú
mostrarMenu();