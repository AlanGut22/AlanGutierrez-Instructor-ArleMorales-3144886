import * as readline from 'readline';

const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout
});

interface Paciente {
	id: string;
	nombre: string;
}

interface Medico {
	id: string;
	nombre: string;
	especialidad: string;
}

interface Cita {
	pacienteId: string;
	medicoId: string;
	fecha: string;
	hora: string;
}

const pacientes: Paciente[] = [
	{ id: 'p1', nombre: 'Juan Pérez' },
	{ id: 'p2', nombre: 'Ana Torres' }
];

const medicos: Medico[] = [
	{ id: 'm1', nombre: 'Dra. Gómez', especialidad: 'cardiologia' },
	{ id: 'm2', nombre: 'Dr. Ruiz', especialidad: 'Pediatría' }
];

const citas: Cita[] = [
	{ pacienteId: 'p1', medicoId: 'm1', fecha: '2025-05-16', hora: '10:00' },
	{ pacienteId: 'p2', medicoId: 'm2', fecha: '2025-05-16', hora: '11:00' }
];

function filtrarPorEspecialidad(especialidad: string) {
	const medicosFiltrados = medicos.filter(m => m.especialidad === especialidad).map(m => m.id);
	const citasFiltradas = citas.filter(c => medicosFiltrados.includes(c.medicoId));
	console.log('Citas encontradas:', citasFiltradas);
}

function citasDePaciente(pacienteId: string) {
	const resultado = citas.filter(c => c.pacienteId === pacienteId);
	console.log('Citas del paciente:', resultado);
}

function citasPorFecha(fecha: string) {
	const resultado = citas.filter(c => c.fecha === fecha);
	console.log('Citas en la fecha:', resultado);
}

function generarReporte(fecha: string) {
	const citasDelDia = citas.filter(c => c.fecha === fecha);
	citasDelDia.forEach(c => {
		const paciente = pacientes.find(p => p.id === c.pacienteId)?.nombre;
		const medico = medicos.find(m => m.id === c.medicoId);
		console.log(`Hora: ${c.hora}, Paciente: ${paciente}, Médico: ${medico?.nombre}, Especialidad: ${medico?.especialidad}`);
	});
}

function verificarDisponibilidad(medicoId: string, fecha: string, hora: string) {
	const ocupada = citas.some(c => c.medicoId === medicoId && c.fecha === fecha && c.hora === hora);
	console.log(ocupada ? 'No disponible' : 'Disponible');
}

function mostrarMenu() {
	console.log('\n--- MENÚ ---');
	console.log('1. Filtrar citas por especialidad');
	console.log('2. Ver citas de un paciente');
	console.log('3. Ver citas por fecha');
	console.log('4. Generar reporte diario');
	console.log('5. Verificar disponibilidad');
	console.log('6. Salir');

	rl.question('Elige una opción: ', (op) => {
		switch (op) {
			case '1':
				rl.question('Especialidad: ', (esp) => {
					filtrarPorEspecialidad(esp);
					mostrarMenu();
				});
				break;
			case '2':
				rl.question('ID del paciente: ', (id) => {
					citasDePaciente(id);
					mostrarMenu();
				});
				break;
			case '3':
				rl.question('Fecha (YYYY-MM-DD): ', (f) => {
					citasPorFecha(f);
					mostrarMenu();
				});
				break;
			case '4':
				rl.question('Fecha (YYYY-MM-DD): ', (f) => {
					generarReporte(f);
					mostrarMenu();
				});
				break;
			case '5':
				rl.question('ID del médico: ', (m) => {
					rl.question('Fecha: ', (f) => {
						rl.question('Hora: ', (h) => {
							verificarDisponibilidad(m, f, h);
							mostrarMenu();
						});
					});
				});
				break;
			case '6':
				rl.close();
				break;
			default:
				console.log('Opción inválida');
				mostrarMenu();
		}
	});
}

mostrarMenu();