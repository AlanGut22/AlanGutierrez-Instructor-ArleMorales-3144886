import readline from 'readline';

const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout,
});

type Equipo = {
	nombre: string;
	valor: number;
	asignado: boolean;
	aula?: string;
};

const equipos: Equipo[] = [
	{ nombre: 'Proyector', valor: 2000000, asignado: true, aula: 'aula 1' },
	{ nombre: 'Computador', valor: 1500000, asignado: false },
	{ nombre: 'Pantalla LED', valor: 1000000, asignado: true, aula: 'aula 2' },
	{ nombre: 'Proyector', valor: 1800000, asignado: false },
	{ nombre: 'Teclado', valor: 300000, asignado: true, aula: 'aula 3' },
];

const aulas: string[] = ['aula 1', 'aula 2', 'aula 3', 'aula 4'];

function mostrarEquiposDisponibles() {
	const disponibles = equipos.filter(e => !e.asignado);
	console.log('\nEquipos disponibles:');
	disponibles.forEach(e => console.log(`- ${e.nombre} ($${e.valor})`));
}

function mostrarEquiposPorAula(aula: string) {
	const asignados = equipos.filter(e => e.aula === aula);
	console.log(`\nEquipos en ${aula}:`);
	if (asignados.length === 0) {
		console.log('No hay equipos asignados.');
	} else {
		asignados.forEach(e => console.log(`- ${e.nombre} ($${e.valor})`));
	}
}

function mostrarInventario() {
	console.log('\nInventario completo:');
	equipos.forEach(e => {
		console.log(`- ${e.nombre} | Valor: $${e.valor} | Aula: ${e.aula ?? 'No asignado'}`);
	});
}

function aulasSinProyector() {
	const aulasSin = aulas.filter(aula => {
		return !equipos.some(e => e.nombre === 'Proyector' && e.aula === aula);
	});
	console.log('\nAulas sin proyector:');
	aulasSin.forEach(a => console.log(`- ${a}`));
}

function calcularValorPorAula(aula: string) {
	const total = equipos
		.filter(e => e.aula === aula)
		.reduce((suma, e) => suma + e.valor, 0);
	console.log(`\nValor total de equipos en ${aula}: $${total}`);
}

function mostrarMenu() {
	console.log('\n--- GESTIÓN DE EQUIPOS Y AULAS ---');
	console.log('1. Ver equipos disponibles');
	console.log('2. Ver equipos asignados a un aula');
	console.log('3. Ver inventario');
	console.log('4. Ver aulas sin proyector');
	console.log('5. Calcular valor de equipos por aula');
	console.log('6. Salir');
}

function iniciar() {
	mostrarMenu();
	rl.question('\nSeleccione una opción: ', (opcion) => {
		switch (opcion) {
			case '1':
				mostrarEquiposDisponibles();
				iniciar();
				break;
			case '2':
				rl.question('Ingrese el nombre del aula: ', (aula) => {
					mostrarEquiposPorAula(aula);
					iniciar();
				});
				break;
			case '3':
				mostrarInventario();
				iniciar();
				break;
			case '4':
				aulasSinProyector();
				iniciar();
				break;
			case '5':
				rl.question('Ingrese el nombre del aula: ', (aula) => {
					calcularValorPorAula(aula);
					iniciar();
				});
				break;
			case '6':
				rl.close();
				break;
			default:
				console.log('Opción no válida.');
				iniciar();
		}
	});
}

iniciar();