import readline from 'readline';

type Equipo = {
	id: string;
	nombre: string;
	valor: number;
	asignado: boolean;
	aulaAsignada?: string;
};

const equipos: Equipo[] = [
	{ id: 'e1', nombre: 'Proyector', valor: 2000000, asignado: false },
	{ id: 'e2', nombre: 'Computadora', valor: 1500000, asignado: true, aulaAsignada: 'aula 1' },
	{ id: 'e3', nombre: 'Pantalla LED', valor: 800000, asignado: false },
	{ id: 'e4', nombre: 'Proyector', valor: 2200000, asignado: true, aulaAsignada: 'aula 2' },
	{ id: 'e5', nombre: 'Teclado', valor: 500000, asignado: true, aulaAsignada: 'aula 3' },
	{ id: 'e6', nombre: 'Computadora', valor: 1600000, asignado: false },
	{ id: 'e7', nombre: 'Proyector', valor: 2100000, asignado: false },
];

const aulas: string[] = ['Aula 1', 'Aula 2', 'Aula 3', 'Aula 4'];

// Funciones requeridas

// 1. Filtrar equipos disponibles
function filtrarEquiposDisponibles(): Equipo[] {
	return equipos.filter((e) => !e.asignado);
}

// 2. Obtener todos los equipos asignados a un aula específica
function obtenerEquiposPorAula(aula: string): Equipo[] {
	return equipos.filter((e) => e.aulaAsignada === aula);
}

// 3. Transformar datos de equipos para generar un inventario
function generarInventario(): string {
	return equipos.map((e) => `ID: ${e.id}, Nombre: ${e.nombre}, Valor: $${e.valor}, Asignado: ${e.asignado ? 'Sí' : 'No'}, Aula: ${e.aulaAsignada || 'No asignado'}`).join('\n');
}

// 4. Verificar aulas sin equipos esenciales
function verificarAulasSinEquipoEsencial(): string[] {
	const aulasSinProyector = aulas.filter((aula) => {
		return !equipos.some((e) => e.aulaAsignada === aula && e.nombre === 'Proyector');
	});
	return aulasSinProyector;
}

// 5. Calcular el valor total de equipos asignados por aula
function calcularValorTotalPorAula(aula: string): number {
	const equiposAula = equipos.filter((e) => e.aulaAsignada === aula);
	return equiposAula.reduce((total, equipo) => total + equipo.valor, 0);
}

// Interfaz de consola
const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout,
});

function mostrarMenu() {
	console.log('\n--- MENÚ DE REGISTRO DE EQUIPOS Y AULAS ---');
	console.log('1. Filtrar equipos disponibles');
	console.log('2. Obtener equipos asignados a un aula');
	console.log('3. Generar inventario de equipos');
	console.log('4. Verificar aulas sin equipos esenciales (por ejemplo, proyector)');
	console.log('5. Calcular el valor total de equipos asignados por aula');
	console.log('6. Salir');
}

function iniciarMenu() {
	mostrarMenu();
	rl.question('\nSeleccione una opción: ', (opcion) => {
		switch (opcion) {
			case '1':
				const disponibles = filtrarEquiposDisponibles();
				console.log('\nEquipos disponibles (no asignados):');
				disponibles.forEach((e) => console.log(`ID: ${e.id} - Nombre: ${e.nombre} - Valor: $${e.valor}`));
				iniciarMenu();
				break;
			case '2':
				rl.question('Ingrese el nombre del aula: ', (aula) => {
					const equiposAula = obtenerEquiposPorAula(aula);
					console.log(`\nEquipos asignados a ${aula}:`);
					equiposAula.forEach((e) => console.log(`ID: ${e.id} - Nombre: ${e.nombre} - Valor: $${e.valor}`));
					iniciarMenu();
				});
				break;
			case '3':
				console.log('\nInventario de equipos:');
				console.log(generarInventario());
				iniciarMenu();
				break;
			case '4':
				const aulasSinProyector = verificarAulasSinEquipoEsencial();
				console.log('\nAulas sin proyector:');
				aulasSinProyector.forEach((aula) => console.log(aula));
				iniciarMenu();
				break;
			case '5':
				rl.question('Ingrese el nombre del aula: ', (aula) => {
					const valorTotal = calcularValorTotalPorAula(aula);
					console.log(`\nEl valor total de los equipos asignados a ${aula} es: $${valorTotal}`);
					iniciarMenu();
				});
				break;
			case '6':
				rl.close();
				break;
			default:
				console.log('Opción inválida');
				iniciarMenu();
		}
	});
}

iniciarMenu();