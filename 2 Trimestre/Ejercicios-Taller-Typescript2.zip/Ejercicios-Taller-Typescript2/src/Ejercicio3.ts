import readline from 'readline';

const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout,
});

type Estado = 'pendiente' | 'preparación' | 'lista' | 'entregada';

interface Comanda {
	id: string;
	mesa: number;
	platos: string[];
	estado: Estado;
	hora: string;
	fecha: string;
}

const platosPrecios: { [nombre: string]: number } = {
	Hamburguesa: 20000,
	Pizza: 25000,
	Ensalada: 15000,
	Pasta: 22000,
};

const comandas: Comanda[] = [
	{ id: 'c1', mesa: 1, platos: ['Pizza', 'Ensalada'], estado: 'pendiente', hora: '12:00', fecha: '2025-05-12' },
	{ id: 'c2', mesa: 2, platos: ['Hamburguesa'], estado: 'preparación', hora: '13:00', fecha: '2025-05-12' },
	{ id: 'c3', mesa: 3, platos: ['Pasta'], estado: 'entregada', hora: '14:30', fecha: '2025-05-12' },
	{ id: 'c4', mesa: 1, platos: ['Pizza'], estado: 'lista', hora: '13:15', fecha: '2025-05-12' },
];

function filtrarPorEstado(estado: Estado) {
	return comandas.filter(c => c.estado === estado);
}

function totalPorMesa(mesa: number) {
	let total = 0;
	comandas.forEach(c => {
		if (c.mesa === mesa) {
			c.platos.forEach(p => {
				total += platosPrecios[p] || 0;
			});
		}
	});
	return total;
}

function comandasParaCocina() {
	return comandas
		.filter(c => c.estado === 'pendiente' || c.estado === 'preparación')
		.map(c => `Mesa ${c.mesa}: ${c.platos.join(', ')} (${c.estado})`);
}

function platosMasVendidos(fecha: string) {
	const conteo: { [plato: string]: number } = {};
	comandas.forEach(c => {
		if (c.fecha === fecha) {
			c.platos.forEach(p => {
				conteo[p] = (conteo[p] || 0) + 1;
			});
		}
	});
	return conteo;
}

function comandasPorHora() {
	const horas: { [hora: string]: number } = {};
	comandas.forEach(c => {
		const h = c.hora.split(':')[0];
		horas[h] = (horas[h] || 0) + 1;
	});
	return horas;
}

function mostrarMenu() {
	console.log('\n--- MENÚ DE PEDIDOS ---');
	console.log('1. Filtrar comandas por estado');
	console.log('2. Calcular total por mesa');
	console.log('3. Ver comandas para cocina');
	console.log('4. Ver platos más vendidos por fecha');
	console.log('5. Ver cantidad de comandas por hora');
	console.log('6. Salir');
}

function iniciar() {
	mostrarMenu();
	rl.question('\nSeleccione una opción: ', (op) => {
		switch (op) {
			case '1':
				rl.question('Ingrese el estado: ', (estado) => {
					const resultado = filtrarPorEstado(estado as Estado);
					resultado.forEach(c => console.log(`Comanda ${c.id} - Mesa ${c.mesa} - Estado: ${c.estado}`));
					iniciar();
				});
				break;
			case '2':
				rl.question('Número de mesa: ', (m) => {
					const total = totalPorMesa(parseInt(m));
					console.log(`Total a pagar: $${total}`);
					iniciar();
				});
				break;
			case '3':
				const cocina = comandasParaCocina();
				cocina.forEach(l => console.log(l));
				iniciar();
				break;
			case '4':
				rl.question('Ingrese la fecha (YYYY-MM-DD): ', (f) => {
					const conteo = platosMasVendidos(f);
					Object.entries(conteo).forEach(([plato, cantidad]) =>
						console.log(`${plato}: ${cantidad}`)
					);
					iniciar();
				});
				break;
			case '5':
				const horas = comandasPorHora();
				Object.entries(horas).forEach(([hora, cant]) =>
					console.log(`${hora}:00 - ${cant} comandas`)
				);
				iniciar();
				break;
			case '6':
				console.log('Saliendo...');
				rl.close();
				break;
			default:
				console.log('Opción no válida');
				iniciar();
		}
	});
}

iniciar();