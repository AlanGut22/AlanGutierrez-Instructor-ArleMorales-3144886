import readline from 'readline';

type Estado = 'pendiente' | 'preparación' | 'lista' | 'entregada';

interface Plato {
	nombre: string;
	precio: number;
}

interface Comanda {
	id: string;
	mesa: number;
	platos: string[];
	estado: Estado;
	hora: string; // formato HH:MM
	fecha: string; // formato YYYY-MM-DD
}

// Base de datos simulada
const platosDisponibles: Plato[] = [
	{ nombre: 'Hamburguesa', precio: 20000 },
	{ nombre: 'Pizza', precio: 25000 },
	{ nombre: 'Ensalada', precio: 15000 },
	{ nombre: 'Pasta', precio: 22000 },
];

const comandas: Comanda[] = [
	{ id: 'c1', mesa: 1, platos: ['Hamburguesa', 'Ensalada'], estado: 'pendiente', hora: '12:30', fecha: '2025-05-12' },
	{ id: 'c2', mesa: 2, platos: ['Pizza'], estado: 'preparación', hora: '13:00', fecha: '2025-05-12' },
	{ id: 'c3', mesa: 1, platos: ['Pasta', 'Pizza'], estado: 'entregada', hora: '14:15', fecha: '2025-05-12' },
	{ id: 'c4', mesa: 3, platos: ['Pizza'], estado: 'lista', hora: '13:30', fecha: '2025-05-11' },
	{ id: 'c5', mesa: 2, platos: ['Ensalada', 'Ensalada'], estado: 'entregada', hora: '14:00', fecha: '2025-05-12' },
];

// Funciones requeridas

function filtrarComandasPorEstado(estado: Estado): Comanda[] {
	return comandas.filter((c) => c.estado === estado);
}

function calcularTotalMesa(mesa: number): number {
	let total = 0;
	for (const c of comandas.filter((c) => c.mesa === mesa)) {
		for (const nombre of c.platos) {
			const plato = platosDisponibles.find((p) => p.nombre === nombre);
			if (plato) total += plato.precio;
		}
	}
	return total;
}

function generarComandasParaCocina(): string[] {
	return comandas
		.filter((c) => c.estado === 'pendiente' || c.estado === 'preparación')
		.map((c) => `Mesa ${c.mesa}: ${c.platos.join(', ')} (${c.estado})`);
}

function obtenerPlatosMasVendidos(fecha: string): Record<string, number> {
	const conteo: Record<string, number> = {};
	for (const c of comandas.filter((c) => c.fecha === fecha)) {
		for (const plato of c.platos) {
			conteo[plato] = (conteo[plato] || 0) + 1;
		}
	}
	return conteo;
}

function agruparComandasPorHora(): Record<string, number> {
	const grupos: Record<string, number> = {};
	for (const c of comandas) {
		const hora = c.hora.split(':')[0]; // solo la hora
		grupos[hora] = (grupos[hora] || 0) + 1;
	}
	return grupos;
}

// Interfaz por consola
const rl = readline.createInterface({
	input: process.stdin,
	output: process.stdout,
});

function mostrarMenu() {
	console.log('\n--- MENÚ COMANDAS RESTAURANTE ---');
	console.log('1. Filtrar comandas por estado');
	console.log('2. Calcular total a pagar por mesa');
	console.log('3. Ver comandas para cocina');
	console.log('4. Ver platos más vendidos en una fecha');
	console.log('5. Ver cantidad de comandas por hora');
	console.log('6. Salir');
}

function iniciarMenu() {
	mostrarMenu();
	rl.question('\nSeleccione una opción: ', (opcion) => {
		switch (opcion) {
			case '1':
				rl.question('Ingrese estado (pendiente, preparación, lista, entregada): ', (estado) => {
					const resultado = filtrarComandasPorEstado(estado as Estado);
					console.log('\nComandas:');
					resultado.forEach((c) =>
						console.log(`Comanda ${c.id} - Mesa ${c.mesa} - ${c.platos.join(', ')} - ${c.estado}`)
					);
					iniciarMenu();
				});
				break;
			case '2':
				rl.question('Ingrese número de mesa: ', (mesa) => {
					const total = calcularTotalMesa(Number(mesa));
					console.log(`\nTotal a pagar por mesa ${mesa}: $${total}`);
					iniciarMenu();
				});
				break;
			case '3':
				const ordenes = generarComandasParaCocina();
				console.log('\nComandas para cocina:');
				ordenes.forEach((o) => console.log(o));
				iniciarMenu();
				break;
			case '4':
				rl.question('Ingrese fecha (YYYY-MM-DD): ', (fecha) => {
					const vendidos = obtenerPlatosMasVendidos(fecha);
					console.log('\nPlatos más vendidos:');
					for (const [plato, cantidad] of Object.entries(vendidos)) {
						console.log(`${plato}: ${cantidad}`);
					}
					iniciarMenu();
				});
				break;
			case '5':
				const grupos = agruparComandasPorHora();
				console.log('\nComandas agrupadas por hora:');
				for (const [hora, cantidad] of Object.entries(grupos)) {
					console.log(`${hora}:00 - ${cantidad} comandas`);
				}
				iniciarMenu();
				break;
			case '6':
				rl.close();
				break;
			default:
				console.log('Opción inválida');
				iniciarMenu();
		}
	});
}

iniciarMenu();