// index.ts
import * as readline from 'readline';
import { ejercicio1 } from './Ejercicios Arrays/Ejercicio1';
import { ejercicio2 } from './Ejercicios Arrays/Ejercicio2';
import { ejercicio3 } from './Ejercicios Arrays/Ejercicio3';
import { ejercicio4 } from './Ejercicios Arrays/Ejercicio4';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const preguntar = (texto: string): Promise<string> => {
    return new Promise(resolve => rl.question(texto, resolve));
};

async function menuPrincipal() {
    while (true) {
        console.log("\nMenú principal:");
        console.log("1. Hotel");
        console.log("2. Banco");
        console.log("3. Supermercado");
        console.log("4. Máquina Expendedora");
        console.log("5. Salir");

        const opcion = await preguntar("Elige una opción: ");

        switch (opcion) {
            case "1":
                console.log("\nCargando el ejercicio de Hotel...");
                await ejercicio1(rl);
                break;
            case "2":
                console.log("\nCargando el ejercicio de Banco...");
                await ejercicio2(rl);
                break;
            case "3":
                console.log("\nCargando el ejercicio de Supermercado...");
                await ejercicio3(rl);
                break;
            case "4":
                console.log("\nCargando el ejercicio de Máquina Expendedora...");
                await ejercicio4(rl);
                break;
            case "5":
                console.log("Saliendo del programa...");
                rl.close();
                return;
            default:
                console.log("Opción inválida. Intenta de nuevo.");
        }
    }
}

menuPrincipal();