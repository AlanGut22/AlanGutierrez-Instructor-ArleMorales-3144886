import * as readline from 'readline';

let saldo = 0;
let transacciones: string[] = [];


export const ejercicio2 = async (rl: readline.Interface) => {

	const preguntar = (texto: string): Promise<string> => {
		return new Promise(resolve => rl.question(texto, resolve));
	};

	while (true) {
		const opcion = await preguntar(
			"1. Consultar saldo\n2. Depositar\n3. Retirar\n4. Ver transacciones\n5. Salir\nElige una opción: "
		);

		switch (opcion) {
			case "1":
				console.log(`\nTu saldo actual es: $${saldo}`);
				break;

			case "2":
				const montoDeposito = parseFloat(await preguntar("Ingrese el monto a depositar: "));
				if (isNaN(montoDeposito) || montoDeposito <= 0) {
					console.log("Monto inválido.");
				} else {
					saldo += montoDeposito;
					transacciones.push(`Depósito: +$${montoDeposito}`);
					console.log(`\nDepósito exitoso. Nuevo saldo: $${saldo}`);
				}
				break;

			case "3":
				const montoRetiro = parseFloat(await preguntar("Ingrese el monto a retirar: "));
				if (isNaN(montoRetiro) || montoRetiro <= 0) {
					console.log("Monto inválido.");
				} else if (montoRetiro > saldo) {
					console.log("Fondos insuficientes.");
				} else {
					saldo -= montoRetiro;
					transacciones.push(`Retiro: -$${montoRetiro}`);
					console.log(`\nRetiro exitoso. Nuevo saldo: $${saldo}`);
				}
				break;

			case "4":
				console.log("\nHistorial de transacciones:");
				if (transacciones.length === 0) {
					console.log("No hay transacciones.");
				} else {
					transacciones.forEach((t, i) => console.log(`${i + 1}. ${t}`));
				}
				break;

			case "5":
				console.log("Saliendo del ejercicio de Banco...");
				return;

			default:
				console.log("Opción inválida.");
		}
	}
};