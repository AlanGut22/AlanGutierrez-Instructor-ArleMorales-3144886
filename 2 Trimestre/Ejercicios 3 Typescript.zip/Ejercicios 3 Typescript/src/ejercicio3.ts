// Interfaz que representa un producto
interface Producto {
	nombre: string;
	precio: number;
	stock: number;
	categoria?: string; // opcional
}

// Interfaz para el inventario
interface Inventario {
	productos: Producto[];

	agregarProducto(producto: Producto): void;
	buscarProducto(nombre: string): Producto | undefined;
}

// Clase que implementa la interfaz Inventario
class Tienda implements Inventario {
	productos: Producto[] = [];

	agregarProducto(producto: Producto): void {
		this.productos.push(producto);
		console.log(`Producto "${producto.nombre}" agregado al inventario.`);
	}

	buscarProducto(nombre: string): Producto | undefined {
		const encontrado = this.productos.find(p => p.nombre.toLowerCase() === nombre.toLowerCase());
		if (encontrado) {
			console.log(`Producto encontrado: ${encontrado.nombre} - $${encontrado.precio} - Stock: ${encontrado.stock}`);
		} else {
			console.log(`Producto "${nombre}" no encontrado.`);
		}
		return encontrado;
	}
}

// Ejemplo de uso
const miTienda = new Tienda();

miTienda.agregarProducto({ nombre: "Camisa", precio: 45000, stock: 10, categoria: "Ropa" });
miTienda.agregarProducto({ nombre: "Zapatos", precio: 120000, stock: 5 });

miTienda.buscarProducto("camisa");
miTienda.buscarProducto("pantalón");