// Interfaz base para todos los usuarios
interface Usuario {
	nombre: string;
	correo: string;
	activo: boolean;
}

// Interfaz para administradores, hereda de Usuario
interface Administrador extends Usuario {
	nivelAcceso: string; // por ejemplo: "superadmin", "editor", etc.
}

// Función que recibe un Usuario o un Administrador e imprime sus datos
function imprimirDatosUsuario(usuario: Usuario): void {
	console.log(`Nombre: ${usuario.nombre}`);
	console.log(`Correo: ${usuario.correo}`);
	console.log(`Activo: ${usuario.activo ? "Sí" : "No"}`);

	// Verificamos si el usuario también es Administrador
	if ("nivelAcceso" in usuario) {
		const admin = usuario as Administrador;
		console.log(`Nivel de acceso: ${admin.nivelAcceso}`);
	}
}

// Ejemplo de uso
const usuarioNormal: Usuario = {
	nombre: "Carlos Pérez",
	correo: "carlos@example.com",
	activo: true
};

const admin: Administrador = {
	nombre: "Laura Gómez",
	correo: "laura@example.com",
	activo: true,
	nivelAcceso: "superadmin"
};

// Pruebas
console.log("=== Usuario normal ===");
imprimirDatosUsuario(usuarioNormal);

console.log("\n=== Administrador ===");
imprimirDatosUsuario(admin);