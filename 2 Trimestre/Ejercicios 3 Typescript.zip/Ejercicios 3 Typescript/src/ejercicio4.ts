// Interfaz base con propiedad común 'id'
interface ObjetoBase {
	id: number;
}

// Interfaz de Usuario
interface Usuario extends ObjetoBase {
	nombre: string;
	correo: string;
}

// Interfaz de Producto
interface Producto extends ObjetoBase {
	nombre: string;
	precio: number;
}

// Interfaz de Orden
interface Orden extends ObjetoBase {
	usuarioId: number;
	productos: Producto[];
	total: number;
}

// Función genérica que imprime datos de cualquier objeto que extienda ObjetoBase
function imprimirDatos<T extends ObjetoBase>(objeto: T): void {
	console.log("=== Datos del objeto ===");
	for (const [clave, valor] of Object.entries(objeto)) {
		console.log(`${clave}: ${JSON.stringify(valor)}`);
	}
}

// Ejemplo de uso
const usuario: Usuario = {
	id: 1,
	nombre: "Ana Torres",
	correo: "ana@example.com"
};

const producto: Producto = {
	id: 101,
	nombre: "Audífonos",
	precio: 89900
};

const orden: Orden = {
	id: 5001,
	usuarioId: 1,
	productos: [producto],
	total: 89900
};

// Pruebas
imprimirDatos(usuario);
imprimirDatos(producto);
imprimirDatos(orden);
