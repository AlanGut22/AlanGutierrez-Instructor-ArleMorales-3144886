// Interfaz base con propiedades comunes a todos los vehículos
interface Vehiculo {
	modelo: string;
	año: number;
	color: string;
	marca: string;
}

// Interfaz para automóviles, hereda de Vehiculo
interface Automovil extends Vehiculo {
	cantidadPuertas: number;
	capacidadMaletero: number; // en litros
}

// Interfaz para motocicletas, hereda de Vehiculo
interface Motocicleta extends Vehiculo {
	tieneSidecar: boolean;
	cilindrada: number; // en centímetros cúbicos (cc)
}

// Clase que implementa la interfaz Automovil
class Sedan implements Automovil {
	constructor(
		public modelo: string,
		public año: number,
		public color: string,
		public marca: string,
		public cantidadPuertas: number,
		public capacidadMaletero: number
	) { }

	mostrarInformacion(): void {
		console.log(`Automóvil: ${this.marca} ${this.modelo} (${this.año}) - Color: ${this.color}`);
		console.log(`Puertas: ${this.cantidadPuertas}, Maletero: ${this.capacidadMaletero}L`);
	}
}

// Clase que implementa la interfaz Motocicleta
class MotocicletaCruzero implements Motocicleta {
	constructor(
		public modelo: string,
		public año: number,
		public color: string,
		public marca: string,
		public tieneSidecar: boolean,
		public cilindrada: number
	) { }

	mostrarInformacion(): void {
		console.log(`Motocicleta: ${this.marca} ${this.modelo} (${this.año}) - Color: ${this.color}`);
		console.log(`Sidecar: ${this.tieneSidecar ? "Sí" : "No"}, Cilindrada: ${this.cilindrada}cc`);
	}
}

// Ejemplo de uso
const miAuto = new Sedan("Civic", 2022, "Rojo", "Honda", 4, 450);
const miMoto = new MotocicletaCruzero("Shadow", 2020, "Negro", "Honda", false, 750);

miAuto.mostrarInformacion();
miMoto.mostrarInformacion();