// Definición de la interfaz BaseDeDatos
interface BaseDeDatos {
	conectar(): void;
	buscar(tabla: string, id: number): void;
	actualizar(tabla: string, id: number, datos: object): void;
	desconectar(): void;
}

// Implementación para MySQL
class BaseDeDatosMySQL implements BaseDeDatos {
	conectar(): void {
		console.log("Conectado a la base de datos MySQL.");
	}

	buscar(tabla: string, id: number): void {
		console.log(`Buscando en la tabla '${tabla}' el registro con ID = ${id} en MySQL...`);
	}

	actualizar(tabla: string, id: number, datos: object): void {
		console.log(`Actualizando el registro con ID = ${id} en la tabla '${tabla}' en MySQL con los datos:`, datos);
	}

	desconectar(): void {
		console.log("Conexión a MySQL cerrada.");
	}
}

// Implementación para SQLite
class BaseDeDatosSQLite implements BaseDeDatos {
	conectar(): void {
		console.log("Conectado a la base de datos SQLite (archivo local).");
	}

	buscar(tabla: string, id: number): void {
		console.log(`Consultando el archivo local SQLite: buscando en '${tabla}' el ID ${id}...`);
	}

	actualizar(tabla: string, id: number, datos: object): void {
		console.log(`Modificando registro en SQLite tabla '${tabla}', ID ${id}, nuevos datos:`, datos);
	}

	desconectar(): void {
		console.log("SQLite desconectado (archivo cerrado).");
	}
}

// Función para usar cualquier BaseDeDatos
function usarBaseDeDatos(db: BaseDeDatos) {
	db.conectar();
	db.buscar("usuarios", 1);
	db.actualizar("usuarios", 1, { nombre: "Ana", activo: true });
	db.desconectar();
}

// Crear instancias y usar
const mysql = new BaseDeDatosMySQL();
const sqlite = new BaseDeDatosSQLite();

console.log("\n--- Usando MySQL ---");
usarBaseDeDatos(mysql);

console.log("\n--- Usando SQLite ---");
usarBaseDeDatos(sqlite);
