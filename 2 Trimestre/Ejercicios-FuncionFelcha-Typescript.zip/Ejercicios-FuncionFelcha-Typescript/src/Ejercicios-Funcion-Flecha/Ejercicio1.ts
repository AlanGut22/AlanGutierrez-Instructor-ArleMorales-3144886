import * as readline from 'readline';

// Arreglo para las 5 habitaciones (0 = libre, 1 = ocupada)
let habitaciones: number[] = [0, 0, 0, 0, 0];

// Función flecha para mostrar estado de habitaciones
const mostrarEstado = (): void => {
	let estado = "Estado de habitaciones:\n";
	for (let i = 0; i < habitaciones.length; i++) {
		estado += `Habitación ${i + 1}: ${habitaciones[i] === 0 ? "Libre" : "Ocupada"}\n`;
	}
	console.log(estado);
};

// Función flecha para contar habitaciones libres
const contarHabitacionesLibres = (): number => {
	return habitaciones.filter(h => h === 0).length;
};

// Función flecha para reservar una habitación
const reservarHabitacion = (num: number): void => {
	if (num < 1 || num > 5) {
		console.log("Número de habitación inválido. Usa 1-5.");
	} else if (habitaciones[num - 1] === 1) {
		console.log("Habitación ya ocupada.");
	} else {
		habitaciones[num - 1] = 1;
		console.log(`Habitación ${num} reservada con éxito.`);
	}
};

// Función flecha para liberar una habitación
const liberarHabitacion = (num: number): void => {
	if (num < 1 || num > 5) {
		console.log("Número de habitación inválido. Usa 1-5.");
	} else if (habitaciones[num - 1] === 0) {
		console.log("Habitación ya está libre.");
	} else {
		habitaciones[num - 1] = 0;
		console.log(`Habitación ${num} liberada con éxito.`);
	}
};

// Función principal como función flecha
export const ejercicio1 = async (rl: readline.Interface): Promise<void> => {
	const preguntar = (pregunta: string): Promise<string> => {
		return new Promise(resolve => rl.question(pregunta, resolve));
	};

	while (true) {
		const opcion = await preguntar("1. Ver estado\n2. Reservar\n3. Liberar\n4. Salir\nElige una opción: ");

		if (opcion === "1") {
			mostrarEstado();
			console.log(`Habitaciones libres: ${contarHabitacionesLibres()}`);
		} else if (opcion === "2") {
			const num = parseInt(await preguntar("Ingresa el número de habitación (1-5): "));
			reservarHabitacion(num);
			console.log(`Habitaciones libres: ${contarHabitacionesLibres()}`);
		} else if (opcion === "3") {
			const num = parseInt(await preguntar("Ingresa el número de habitación (1-5): "));
			liberarHabitacion(num);
			console.log(`Habitaciones libres: ${contarHabitacionesLibres()}`);
		} else if (opcion === "4") {
			console.log("Saliendo del sistema de hotel...");
			break;
		} else {
			console.log("Opción inválida.");
		}
	}
};
