import * as readline from 'readline';

let colaClientes: string[] = [];

export const ejercicio3 = async (rl: readline.Interface) => {

    const preguntar = (texto: string): Promise<string> => {
        return new Promise(resolve => rl.question(texto, resolve));
    };

    const agregarCliente = async () => {
        if (colaClientes.length >= 7) {
            console.log("La cola está llena. No se pueden agregar más clientes.");
            return;
        }

        const nombre = await preguntar("Ingrese el nombre del cliente: ");
        if (nombre.trim() === "") {
            console.log("Nombre inválido.");
        } else {
            colaClientes.push(nombre.trim());
            console.log(`Cliente ${nombre} agregado a la cola.`);
        }
    };

    const atenderCliente = () => {
        if (colaClientes.length === 0) {
            console.log("No hay clientes en la cola para atender.");
        } else {
            const clienteAtendido = colaClientes.shift();
            console.log(`Atendiendo a ${clienteAtendido}.`);
        }
    };

    const mostrarCola = () => {
        if (colaClientes.length === 0) {
            console.log("La cola está vacía.");
        } else {
            console.log("Clientes en la cola:");
            colaClientes.forEach((cliente, index) => {
                console.log(`${index + 1}. ${cliente}`);
            });
        }
    };

    while (true) {
        const opcion = await preguntar(
            "Menú del Supermercado\n1. Agregar Cliente\n2. Atender Cliente\n3. Ver Cola\n4. Salir\nElige una opción: "
        );

        switch (opcion) {
            case "1":
                await agregarCliente();
                break;
            case "2":
                atenderCliente();
                break;
            case "3":
                mostrarCola();
                break;
            case "4":
                console.log("Saliendo del ejercicio 3...");
                return;
            default:
                console.log("Opción inválida. Inténtalo de nuevo.");
        }
    }
};