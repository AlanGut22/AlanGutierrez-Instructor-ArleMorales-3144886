import * as readline from "readline";

const productos = new Map([
    [1, { nombre: "Chocolate", precio: 3 }],
    [2, { nombre: "Galletas", precio: 2 }],
    [3, { nombre: "Chips", precio: 4 }],
    [4, { nombre: "Refresco", precio: 5 }],
    [5, { nombre: "Caramelo", precio: 1 }]
]);

const stock = new Map([
    [1, 5],
    [2, 4],
    [3, 3],
    [4, 6],
    [5, 8]
]);

function mostrarProductos(): string {
    let mensaje = "Productos disponibles:\n";
    for (const [codigo, producto] of productos) {
        const cantidad = stock.get(codigo);
        mensaje += `${codigo}. ${producto.nombre} - $${producto.precio} (${cantidad} disponibles)\n`;
    }
    return mensaje;
}

function sugerirProducto(): number | null {
    for (const codigo of productos.keys()) {
        if ((stock.get(codigo) ?? 0) > 0) {
            return codigo;
        }
    }
    return null;
}

export async function ejercicio4(rl: readline.Interface) {
    const preguntar = (texto: string): Promise<string> => {
        return new Promise(resolve => rl.question(texto, resolve));
    };

    while (true) {
        console.log("1. Ver productos");
        console.log("2. Comprar");
        console.log("3. Salir");

        const opcion = await preguntar("Elige una opción: ");

        switch (opcion) {
            case "1":
                console.log(mostrarProductos());
                break;

            case "2":
                console.log(mostrarProductos());
                const inputCodigo = await preguntar("Ingrese el código del producto: ");
                const codigo = Number(inputCodigo);

                if (!productos.has(codigo)) {
                    console.log("Código inválido.");
                    break;
                }

                const stockDisponible = stock.get(codigo) ?? 0;
                if (stockDisponible === 0) {
                    const sugerido = sugerirProducto();
                    if (sugerido) {
                        const sugeridoProducto = productos.get(sugerido)!;
                        console.log(`Producto agotado. Te sugerimos: ${sugerido}. ${sugeridoProducto.nombre} - $${sugeridoProducto.precio}`);
                    } else {
                        console.log("No hay productos disponibles.");
                    }
                    break;
                }

                const producto = productos.get(codigo)!;
                const inputCantidad = await preguntar(`¿Cuántos ${producto.nombre} deseas comprar? `);
                const cantidad = Number(inputCantidad);

                if (cantidad <= 0 || cantidad > stockDisponible) {
                    console.log("Cantidad inválida o stock insuficiente.");
                    break;
                }

                const precioTotal = producto.precio * cantidad;
                const inputDinero = await preguntar(`Total a pagar: $${precioTotal}. Ingresa tu dinero: `);
                const dinero = Number(inputDinero);

                if (dinero < precioTotal) {
                    console.log("Dinero insuficiente.");
                    break;
                }

                const cambio = dinero - precioTotal;
                stock.set(codigo, stockDisponible - cantidad);

                console.log(`Compra exitosa: Recibe ${cantidad} ${producto.nombre}.`);
                if (cambio > 0) {
                    console.log(`Tu cambio: $${cambio}`);
                }
                break;

            case "3":
                console.log("Saliendo de la máquina expendedora...");
                return;
            default:
                console.log("Opción inválida.");
        }
    }
}