// Clase base abstracta
abstract class FiguraGeometrica {
	nombre: string;

	constructor(nombre: string) {
		this.nombre = nombre;
	}

	// Método abstracto que debe implementarse en las subclases
	abstract area(): number;

	mostrarArea(): void {
		console.log(`El área del ${this.nombre} es: ${this.area().toFixed(2)}`);
	}
}

// Subclase Triángulo
class Triangulo extends FiguraGeometrica {
	base: number;
	altura: number;

	constructor(base: number, altura: number) {
		super("triángulo");
		this.base = base;
		this.altura = altura;
	}

	area(): number {
		return (this.base * this.altura) / 2;
	}
}

// Subclase Círculo
class Circulo extends FiguraGeometrica {
	radio: number;

	constructor(radio: number) {
		super("círculo");
		this.radio = radio;
	}

	area(): number {
		return Math.PI * this.radio * this.radio;
	}
}

// Subclase Cuadrado
class Cuadrado extends FiguraGeometrica {
	lado: number;

	constructor(lado: number) {
		super("cuadrado");
		this.lado = lado;
	}

	area(): number {
		return this.lado * this.lado;
	}
}

// Crear objetos y mostrar sus áreas
const figura1 = new Triangulo(10, 5);
const figura2 = new Circulo(7);
const figura3 = new Cuadrado(4);

figura1.mostrarArea();  // El área del triángulo es: 25.00
figura2.mostrarArea();  // El área del círculo es: 153.94
figura3.mostrarArea();  // El área del cuadrado es: 16.00