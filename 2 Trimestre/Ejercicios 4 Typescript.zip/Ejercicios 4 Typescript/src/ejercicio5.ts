// Clase base
class Electrodomestico {
	marca: string;
	precio: number;
	color: string;

	constructor(marca: string, precio: number, color: string) {
		this.marca = marca;
		this.precio = precio;
		this.color = color;
	}

	mostrarInfo(): void {
		console.log(`${this.constructor.name} - Marca: ${this.marca}, Precio: $${this.precio}, Color: ${this.color}`);
	}
}

// Subclase Televisor
class Televisor extends Electrodomestico {
	pulgadas: number;

	constructor(marca: string, precio: number, color: string, pulgadas: number) {
		super(marca, precio, color);
		this.pulgadas = pulgadas;
	}

	mostrarInfo(): void {
		super.mostrarInfo();
		console.log(`Tamaño: ${this.pulgadas} pulgadas`);
	}
}

// Subclase Nevera
class Nevera extends Electrodomestico {
	capacidadLitros: number;

	constructor(marca: string, precio: number, color: string, capacidadLitros: number) {
		super(marca, precio, color);
		this.capacidadLitros = capacidadLitros;
	}

	mostrarInfo(): void {
		super.mostrarInfo();
		console.log(`Capacidad: ${this.capacidadLitros} litros`);
	}
}

// Subclase Lavadora
class Lavadora extends Electrodomestico {
	cargaKg: number;

	constructor(marca: string, precio: number, color: string, cargaKg: number) {
		super(marca, precio, color);
		this.cargaKg = cargaKg;
	}

	mostrarInfo(): void {
		super.mostrarInfo();
		console.log(`Carga: ${this.cargaKg} kg`);
	}
}

// Crear objetos y probar
const tv = new Televisor("Samsung", 1200, "Negro", 55);
const nevera = new Nevera("LG", 1800, "Plateado", 400);
const lavadora = new Lavadora("Whirlpool", 1500, "Blanco", 12);

tv.mostrarInfo();
console.log("---");
nevera.mostrarInfo();
console.log("---");
lavadora.mostrarInfo();