class CuentaBancaria {
	numeroCuenta: string;
	titular: string;
	saldo: number;

	constructor(numeroCuenta: string, titular: string, saldoInicial: number = 0) {
		this.numeroCuenta = numeroCuenta;
		this.titular = titular;
		this.saldo = saldoInicial;
	}

	depositar(monto: number): void {
		if (monto > 0) {
			this.saldo += monto;
			console.log(`Se depositaron $${monto}. Nuevo saldo: $${this.saldo}.`);
		} else {
			console.log("El monto a depositar debe ser positivo.");
		}
	}

	retirar(monto: number): void {
		if (monto > 0) {
			if (this.saldo >= monto) {
				this.saldo -= monto;
				console.log(`Se retiraron $${monto}. Nuevo saldo: $${this.saldo}.`);
			} else {
				console.log("Saldo insuficiente para retirar esa cantidad.");
			}
		} else {
			console.log("El monto a retirar debe ser positivo.");
		}
	}

	consultarSaldo(): void {
		console.log(`Saldo actual de la cuenta ${this.numeroCuenta} de ${this.titular}: $${this.saldo}.`);
	}
}

// Crear cuentas
const cuenta1 = new CuentaBancaria("001-23456", "Juan Pérez", 1000);
const cuenta2 = new CuentaBancaria("002-78901", "María Gómez");

// Usar métodos
cuenta1.consultarSaldo();
cuenta1.depositar(500);
cuenta1.retirar(200);
cuenta1.consultarSaldo();

console.log("---");

cuenta2.consultarSaldo();
cuenta2.depositar(1500);
cuenta2.retirar(2000); // debería avisar saldo insuficiente
cuenta2.consultarSaldo();