// Clase base
class Vehiculo {
	marca: string;
	modelo: string;

	constructor(marca: string, modelo: string) {
		this.marca = marca;
		this.modelo = modelo;
	}

	desplazarse(): void {
		console.log(`${this.marca} ${this.modelo} se está desplazando.`);
	}
}

// Subclase Coche
class Coche extends Vehiculo {
	desplazarse(): void {
		console.log(`${this.marca} ${this.modelo} está circulando por carretera.`);
	}
}

// Subclase Barco
class Barco extends Vehiculo {
	desplazarse(): void {
		console.log(`${this.marca} ${this.modelo} está navegando en el agua.`);
	}
}

// Subclase Avión
class Avion extends Vehiculo {
	desplazarse(): void {
		console.log(`${this.marca} ${this.modelo} está volando por el aire.`);
	}
}

// Crear objetos y probar
const coche = new Coche("Toyota", "Corolla");
const barco = new Barco("Yamaha", "WaveRunner");
const avion = new Avion("Boeing", "747");

coche.desplazarse();   // Toyota Corolla está circulando por carretera.
barco.desplazarse();   // Yamaha WaveRunner está navegando en el agua.
avion.desplazarse();   // Boeing 747 está volando por el aire.