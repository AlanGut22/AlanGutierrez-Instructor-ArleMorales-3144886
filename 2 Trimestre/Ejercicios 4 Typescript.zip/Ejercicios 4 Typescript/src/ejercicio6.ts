// Clase Habitación
class Habitacion {
	numero: number;
	precio: number;
	disponible: boolean;

	constructor(numero: number, precio: number) {
		this.numero = numero;
		this.precio = precio;
		this.disponible = true; // Por defecto está disponible
	}

	reservar(): void {
		if (this.disponible) {
			this.disponible = false;
			console.log(`Habitación ${this.numero} reservada exitosamente.`);
		} else {
			console.log(`Habitación ${this.numero} ya está ocupada.`);
		}
	}

	liberar(): void {
		if (!this.disponible) {
			this.disponible = true;
			console.log(`Habitación ${this.numero} ahora está disponible.`);
		} else {
			console.log(`Habitación ${this.numero} ya estaba libre.`);
		}
	}

	mostrarEstado(): void {
		const estado = this.disponible ? "Disponible" : "Ocupada";
		console.log(`Habitación ${this.numero} - $${this.precio} - Estado: ${estado}`);
	}
}

// Clase Hotel
class Hotel {
	nombre: string;
	ubicacion: string;
	habitaciones: Habitacion[] = [];

	constructor(nombre: string, ubicacion: string) {
		this.nombre = nombre;
		this.ubicacion = ubicacion;
	}

	agregarHabitacion(habitacion: Habitacion): void {
		this.habitaciones.push(habitacion);
	}

	mostrarHabitaciones(): void {
		console.log(`Hotel ${this.nombre} - ${this.ubicacion}`);
		this.habitaciones.forEach((hab) => hab.mostrarEstado());
	}

	buscarHabitacion(numero: number): Habitacion | undefined {
		return this.habitaciones.find(h => h.numero === numero);
	}
}

// ------------------------
// Prueba
// ------------------------

const hotel1 = new Hotel("Hotel Sol", "Cartagena");

// Agregar habitaciones
hotel1.agregarHabitacion(new Habitacion(101, 150000));
hotel1.agregarHabitacion(new Habitacion(102, 200000));
hotel1.agregarHabitacion(new Habitacion(103, 250000));

hotel1.mostrarHabitaciones();

console.log("\n Reservando habitación 102:");
const hab102 = hotel1.buscarHabitacion(102);
hab102?.reservar();

console.log("\n Estado actual:");
hotel1.mostrarHabitaciones();

console.log("\n Intentando reservar habitación 102 de nuevo:");
hab102?.reservar();

console.log("\n Liberando habitación 102:");
hab102?.liberar();

console.log("\n Estado final:");
hotel1.mostrarHabitaciones();