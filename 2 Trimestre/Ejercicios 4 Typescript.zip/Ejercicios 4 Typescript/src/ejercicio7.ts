// Clase Película
class Pelicula {
	titulo: string;
	duracion: number; // en minutos
	director: string;

	constructor(titulo: string, duracion: number, director: string) {
		this.titulo = titulo;
		this.duracion = duracion;
		this.director = director;
	}

	mostrarInfo(): void {
		console.log(`${this.titulo} | ${this.duracion} min | Dirigida por: ${this.director}`);
	}
}

// Clase Catálogo de Películas
class CatalogoPeliculas {
	private peliculas: Pelicula[] = [];

	agregarPelicula(pelicula: Pelicula): void {
		this.peliculas.push(pelicula);
		console.log(`Película "${pelicula.titulo}" agregada al catálogo.`);
	}

	buscarPorTitulo(titulo: string): Pelicula | undefined {
		return this.peliculas.find(p => p.titulo.toLowerCase() === titulo.toLowerCase());
	}

	filtrarPorDirector(director: string): Pelicula[] {
		return this.peliculas.filter(p => p.director.toLowerCase() === director.toLowerCase());
	}

	mostrarCatalogo(): void {
		console.log("\nCatálogo de películas:");
		this.peliculas.forEach(p => p.mostrarInfo());
	}
}

// ------------------------
// Prueba del catálogo
// ------------------------

const catalogo = new CatalogoPeliculas();

catalogo.agregarPelicula(new Pelicula("Inception", 148, "Christopher Nolan"));
catalogo.agregarPelicula(new Pelicula("Interstellar", 169, "Christopher Nolan"));
catalogo.agregarPelicula(new Pelicula("Pulp Fiction", 154, "Quentin Tarantino"));
catalogo.agregarPelicula(new Pelicula("Django Unchained", 165, "Quentin Tarantino"));
catalogo.agregarPelicula(new Pelicula("La La Land", 128, "Damien Chazelle"));

catalogo.mostrarCatalogo();

console.log("\nBuscando por título: 'Inception'");
const buscada = catalogo.buscarPorTitulo("Inception");
buscada ? buscada.mostrarInfo() : console.log("Película no encontrada.");

console.log("\nFiltrando por director: 'Quentin Tarantino'");
const filtradas = catalogo.filtrarPorDirector("Quentin Tarantino");
filtradas.length
	? filtradas.forEach(p => p.mostrarInfo())
	: console.log("No se encontraron películas para ese director.");