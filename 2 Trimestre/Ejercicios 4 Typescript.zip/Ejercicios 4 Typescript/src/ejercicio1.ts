class Persona {
	nombre: string;
	edad: number;
	documentoIdentidad: string;

	constructor(nombre: string, edad: number, documentoIdentidad: string) {
		this.nombre = nombre;
		this.edad = edad;
		this.documentoIdentidad = documentoIdentidad;
	}

	caminar(): void {
		console.log(`${this.nombre} está caminando.`);
	}

	hablar(): void {
		console.log(`${this.nombre} está hablando.`);
	}

	comer(): void {
		console.log(`${this.nombre} está comiendo.`);
	}
}

// Crear objetos Persona
const persona1 = new Persona("Juan", 30, "12345678");
const persona2 = new Persona("María", 25, "87654321");

// Interactuar con propiedades y métodos
console.log(`Nombre: ${persona1.nombre}, Edad: ${persona1.edad}, Documento: ${persona1.documentoIdentidad}`);
persona1.caminar();
persona1.hablar();
persona1.comer();

console.log(`Nombre: ${persona2.nombre}, Edad: ${persona2.edad}, Documento: ${persona2.documentoIdentidad}`);
persona2.caminar();
persona2.hablar();
persona2.comer();