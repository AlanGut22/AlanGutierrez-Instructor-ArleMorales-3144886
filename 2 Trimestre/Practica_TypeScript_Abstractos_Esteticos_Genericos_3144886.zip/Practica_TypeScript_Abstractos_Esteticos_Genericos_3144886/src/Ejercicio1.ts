// Clase abstracta
abstract class Instrumento {
	constructor(protected nombre: string) { }

	abstract tocar(): void;

	obtenerNombre(): string {
		return `Instrumento: ${this.nombre}`;
	}
}

// Clase hija Guitarra
class Guitarra extends Instrumento {
	tocar(): void {
		console.log("Rasgueando las cuerdas de la guitarra.");
	}
}

// Clase hija Tambor
class Tambor extends Instrumento {
	tocar(): void {
		console.log("Golpeando el tambor con las baquetas.");
	}
}

// Uso
const miGuitarra = new Guitarra("Guitarra Acústica");
console.log(miGuitarra.obtenerNombre());
miGuitarra.tocar();

const miTambor = new Tambor("Tambor de mano");
console.log(miTambor.obtenerNombre());
miTambor.tocar();