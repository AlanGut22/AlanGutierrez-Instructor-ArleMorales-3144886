class Almacen<T> {
  private elementos: T[] = [];

  agregar(item: T): void {
    this.elementos.push(item);
  }

  eliminar(): T | undefined {
    return this.elementos.pop();
  }

  obtenerTodos(): T[] {
    return this.elementos;
  }

  buscar(predicate: (item: T) => boolean): T[] {
    return this.elementos.filter(predicate);
  }
}

// Prueba con strings
const almacenTextos = new Almacen<string>();
almacenTextos.agregar("manzana");
almacenTextos.agregar("banana");
almacenTextos.agregar("kiwi");
console.log(almacenTextos.buscar(item => item.includes("a"))); 

// Prueba con números
const almacenNumeros = new Almacen<number>();
almacenNumeros.agregar(10);
almacenNumeros.agregar(20);
almacenNumeros.agregar(30);
console.log(almacenNumeros.buscar(num => num > 15)); 